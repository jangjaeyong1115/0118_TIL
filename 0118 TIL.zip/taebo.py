a,b = input().split("(^0^)")
left_cnt = a.count('@')
right_cnt = b.count('@')
print(left_cnt,right_cnt)
