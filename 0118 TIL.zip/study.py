word = input()

delete = "CAMBRIDGE"

for i in delete:
    word = word.replace(i,"")

print(word)